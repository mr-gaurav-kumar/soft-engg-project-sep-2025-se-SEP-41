This repository contains the backend code for the modern banking application. The core of this project is the integration of a local, offline-first Generative AI model to power three intelligent features for both customers and bank employees.

## ✨ Core AI Features
[cite_start]Based on the project requirements[cite: 820, 830, 840], this backend implements:

1.  **KYC & Rule Assistant:** (Employee-facing) Uses Tesseract OCR to scan an uploaded identity document (like a PAN or Aadhaar card) and compares the extracted text against local KYC/RBI guidelines. [cite_start]A local LLM then provides a summary of any missing or invalid information[cite: 820].
2.  [cite_start]**Dispute Evidence Pack Generator:** (Employee-facing) When an employee investigates a transaction, this feature fetches the transaction details from the database, finds *semantically similar* past cases from a local CSV, and uses the LLM to generate a draft explanation for the customer[cite: 830].
3.  **Personal Spending Coach:** (Customer-facing) An AI chatbot that allows a customer to ask natural language questions about their spending (e.g., "How much did I spend on food?"). [cite_start]The AI analyzes their transaction history from the database to provide a detailed answer[cite: 840].

---
## 💻 Tech Stack

### Backend
* **Framework:** Flask
* **Database:** SQLite (via Flask-SQLAlchemy)
* [cite_start]**AI (LLM):** `llama-cpp-python` (running Mistral-7B or Llama) [cite: 582]
* **GPU Support:** NVIDIA CUDA
* **OCR:** Tesseract
* **Data Processing:** Pandas

### Frontend (Test Panel)
* **Framework:** Vue.js 3 (via Vite)
* **HTTP Client:** Axios
* **Runtime:** Node.js (v20+)

---
## 🛠️ Installation & Setup (WSL 2)
This project **must** be run in a WSL 2 (Windows Subsystem for Linux) environment with an NVIDIA GPU to function correctly.

### 1. Environment Setup (WSL 2 with GPU)
First, configure your WSL 2 (Ubuntu) environment.

**A. Install System Dependencies:**
```bash
sudo apt update
sudo apt upgrade -y

# Install Python, Git, and Tesseract OCR
sudo apt install python3-pip python3-venv git tesseract-ocr -y

### B. Install NVIDIA CUDA Toolkit (for GPU support):
# 1. Get the NVIDIA key
wget [https://developer.download.nvidia.com/compute/cuda/repos/wsl-ubuntu/x86_64/cuda-wsl-ubuntu.pin](https://developer.download.nvidia.com/compute/cuda/repos/wsl-ubuntu/x86_64/cuda-wsl-ubuntu.pin)
sudo mv cuda-wsl-ubuntu.pin /etc/apt/preferences.d/cuda-repository-pin-600

# 2. Add the CUDA repository
wget [https://developer.download.nvidia.com/compute/cuda/12.5.1/local_installers/cuda-repo-wsl-ubuntu-12-5-local_12.5.1-1_amd64.deb](https://developer.download.nvidia.com/compute/cuda/12.5.1/local_installers/cuda-repo-wsl-ubuntu-12-5-local_12.5.1-1_amd64.deb)
sudo dpkg -i cuda-repo-wsl-ubuntu-12-5-local_12.5.1-1_amd64.deb
sudo cp /var/cuda-repo-wsl-ubuntu-12-5-local/cuda-*-keyring.gpg /usr/share/keyrings/
sudo apt update

# 3. Install the toolkit
sudo apt -y install cuda-toolkit-12-5

###C. Add CUDA to your PATH: Run this to permanently add CUDA to your terminal's path.
echo -e '\n# Add CUDA to PATH\nexport PATH=/usr/local/cuda/bin:$PATH\nexport LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH' >> ~/.bashrc
source ~/.bashrc


#2. Backend Setup (Python)
#Clone or place the project in a folder (e.g., ~/bankease_project).
# Navigate to the project folder
cd ~/bankease_project

# Create a Python virtual environment
python3 -m venv venv

# Activate the environment
source venv/bin/activate

# Install Python requirements
pip install -r requirements.txt

# Install llama-cpp-python with GPU support
# This will fail if CUDA is not set up correctly
CMAKE_ARGS="-DLLAMA_CUDA=on" FORCE_CMAKE=1 pip install llama-cpp-python --upgrade --force-reinstall

# Download the AI model (4.4GB)
mkdir models
wget -P models/ [https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf](https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf)









#### Aditional
3. Frontend Setup (Vue.js Test Panel)
This is for the separate test UI.

A. Install Node.js v20 (using nvm):

Bash

# Install nvm (Node Version Manager)
curl -o- [https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh](https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh) | bash
source ~/.bashrc

# Install and use Node v20
nvm install 20
nvm use 20
B. Create the Vue Project:

Bash

# Go to your home directory (outside the backend)
cd ~

# Create the project (answer "No" to all prompts)
npm create vite@latest bankease-frontend -- --template vue

# Enter the new folder and install dependencies
cd bankease-frontend
npm install
npm install axios
C. Add UI Code: Open this folder in VS Code (code .) and replace the contents of src/App.vue with the test panel code.

🗂️ 4. Dummy Data Setup
Before running, you must create these files.

A. KYC Rules File:

Path: bankease_project/static/kyc_rules/kyc_rules.txt

Content:

Plaintext

pan
aadhaar
address
RBI KYC clause 3.1(b)
B. Solved Dispute Cases:

Path: bankease_project/static/dispute_data/solved_cases.csv

Content:

Code snippet

case_id,customer_id,date,transaction_id,reason,resolution_notes
1001,1,2025-10-12,1,Failed,Resolved: Incorrect OTP entered by user.
1002,1,2025-10-14,2,Pending,Resolved: Insufficient funds in account.
1003,1,2025-10-15,3,Failed,Resolved: Transaction timed out at gateway.