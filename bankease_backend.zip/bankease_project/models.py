# models.py
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class Customer(db.Model):
    __tablename__ = 'customer'
    id=db.Column(db.Integer,primary_key=True)
    email=db.Column(db.String,unique=True, nullable = False)
    name = db.Column(db.String, nullable = False)
    password_hash = db.Column(db.String, nullable = False) # Storing hash, not plain password
    role = db.Column(db.Integer, default =1) # customer - 1
    date_of_signup = db.Column(db.DateTime, default = datetime.now)
    contact_number = db.Column(db.String, nullable = False)
    account_number = db.Column(db.String, unique=True, nullable = False)
    location = db.Column(db.String, nullable = False)
    pin_code = db.Column(db.String, nullable = False)
    status = db.Column(db.String, default = 'Active') # Active, Flagged, Blocked
    
    # Relationships
    beneficiaries = db.relationship('Beneficiary', foreign_keys='Beneficiary.owner_customer_id', cascade = 'all, delete', backref = 'owner', lazy = True)
    sent_transactions = db.relationship('Transaction', foreign_keys='Transaction.sender_id', cascade = 'all, delete', backref = 'sender', lazy = True)
    received_transactions = db.relationship('Transaction', foreign_keys='Transaction.receiver_id', backref='receiver', lazy=True)
    documents = db.relationship('Document', cascade = 'all, delete', backref = 'customer', lazy = True)
    tasks = db.relationship('Task', foreign_keys='Task.customer_id', cascade = 'all, delete', backref = 'customer', lazy = True)
    llm_interactions = db.relationship('LLM_interaction', cascade = 'all, delete', backref = 'customer', lazy = True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Beneficiary(db.Model):
    __tablename__ = 'beneficiary'
    id=db.Column(db.Integer,primary_key=True)
    # This foreign key links to the customer who *owns* this beneficiary entry
    owner_customer_id = db.Column(db.Integer,db.ForeignKey('customer.id'), nullable = False)
    name = db.Column(db.String, nullable = False)
    account_number = db.Column(db.String, nullable = False) # Account number of the beneficiary

class Bank_employee(db.Model):
    __tablename__ = 'bank_employee'
    id=db.Column(db.Integer,primary_key=True)
    email=db.Column(db.String,unique=True, nullable = False)
    name = db.Column(db.String, nullable = False)
    password_hash = db.Column(db.String, nullable = False)
    role = db.Column(db.Integer, default =2) # 2 for employee
    date_of_regn = db.Column(db.DateTime, default = datetime.now)
    contact_number = db.Column(db.String, nullable = False)
    status = db.Column(db.String, default = 'Active')
    
    manager_id = db.Column(db.Integer, db.ForeignKey('bank_manager.id')) 
    tasks = db.relationship('Task', foreign_keys='Task.employee_id', backref = 'employee', lazy = True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Bank_manager(db.Model):
    __tablename__ = 'bank_manager'
    id=db.Column(db.Integer,primary_key=True)
    email=db.Column(db.String,unique=True, nullable = False)
    name = db.Column(db.String, nullable = False)
    password_hash = db.Column(db.String, nullable = False)
    role = db.Column(db.Integer, default = 0) # 0 for manager/admin
    date_of_regn = db.Column(db.DateTime, default = datetime.now)
    contact_number = db.Column(db.String, nullable = False)
    status = db.Column(db.String, default = 'Active')
    
    employees = db.relationship('Bank_employee', backref = 'manager', lazy = True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Task(db.Model):
    __tablename__ = 'task'
    id=db.Column(db.Integer,primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('bank_employee.id'))
    customer_id = db.Column(db.Integer,db.ForeignKey('customer.id'), nullable = False)
    title = db.Column(db.String, nullable = False)
    description = db.Column(db.String, nullable = False)
    priority = db.Column(db.String, nullable = False)
    remarks = db.Column(db.String)
    due_date = db.Column(db.DateTime)
    status = db.Column(db.String, default = 'Pending')

class Transaction(db.Model):
    __tablename__ = 'transaction'
    id=db.Column(db.Integer,primary_key=True)
    sender_id = db.Column(db.Integer,db.ForeignKey('customer.id'), nullable = False)
    receiver_id = db.Column(db.Integer,db.ForeignKey('customer.id'))
    amount = db.Column(db.Float, nullable = False)
    timestamp = db.Column(db.DateTime, default = datetime.now)
    category = db.Column(db.String, db.ForeignKey('spending_category.name'))
    description = db.Column(db.String)
    status = db.Column(db.String, default = 'Completed') # Completed, Pending, Failed
    type = db.Column(db.String) # e.g., DEBIT, CREDIT

class Document(db.Model):
    __tablename__ = 'document'
    id=db.Column(db.Integer,primary_key=True)
    customer_id = db.Column(db.Integer,db.ForeignKey('customer.id'), nullable = False)
    pan_number = db.Column(db.String) 
    aadhar_number = db.Column(db.String)
    # Store the PATH to the file, not the file itself
    file_path = db.Column(db.String, nullable = False)
    upload_date = db.Column(db.DateTime, default = datetime.now)
    status = db.Column(db.String, default='Pending') # Pending, Verified, Rejected

class Spending_category(db.Model):
    __tablename__ = 'spending_category'
    name = db.Column(db.String, primary_key=True)
    description = db.Column(db.String, nullable = False)
    transactions = db.relationship('Transaction', backref='spending_category', lazy=True)

class LLM_interaction(db.Model):
    __tablename__ = 'llm_interaction'
    id=db.Column(db.Integer,primary_key=True)
    user_id = db.Column(db.Integer,db.ForeignKey('customer.id'), nullable = False)
    ask_msg = db.Column(db.String, nullable = False)
    response_msg = db.Column(db.String, nullable = False)
    msg_time = db.Column(db.DateTime, default = datetime.now)
    response_time = db.Column(db.DateTime)