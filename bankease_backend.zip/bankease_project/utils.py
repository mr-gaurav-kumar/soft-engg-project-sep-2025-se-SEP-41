# utils.py
import os
from functools import wraps
from flask import session, jsonify, current_app
from PIL import Image
import pytesseract
import pandas as pd
from llama_cpp import Llama
from config import Config

# --- LLM Loader ---
# We load the model into memory once when the app starts.
# This avoids reloading the 4.4GB file on every request.
llm = None

def get_llm():
    """Initializes and returns the LLM instance."""
    global llm
    if llm is None:
        print("Loading LLM model...")
        llm = Llama(
            model_path=Config.LLM_MODEL_PATH,
            n_gpu_layers=32,  # Offload as many layers as possible to GPU
            verbose=False
        )
        print("LLM model loaded.")
    return llm

def generate_llm_response(prompt):
    """Generates a response from the loaded LLM."""
    llm_instance = get_llm()
    output = llm_instance(
        prompt,
        max_tokens=250,
        stop=["User:", "Q:"],
        echo=False
    )
    return output['choices'][0]['text'].strip()

# --- Authentication Decorators ---

def login_required(f):
    """Decorator to require login for a route."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'message': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function

def role_required(role):
    """Decorator to require a specific role (0=Manager, 1=Customer, 2=Employee)."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'role' not in session or session['role'] != role:
                return jsonify({'message': 'Permission denied'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# --- AI Feature 1: KYC Helper ---

def extract_text_from_image(image_path):
    """Uses Tesseract OCR to extract text from an image file."""
    try:
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image)
        return text
    except Exception as e:
        print(f"OCR Error: {e}")
        return None

def check_kyc_rules(extracted_text):
    """
    A simple keyword-based rule checker.
    Compares extracted text against rules in a local file.
    """
    try:
        with open(Config.KYC_RULES_PATH, 'r') as f:
            rules = [line.strip().lower() for line in f if line.strip()]
        
        missing_items = []
        text_lower = extracted_text.lower()
        
        # This is a simple example. You can make this logic more complex.
        if "pan" not in text_lower:
            missing_items.append("PAN card details")
        if "aadhaar" not in text_lower:
            missing_items.append("Aadhaar details")
        if "address" not in text_lower:
            missing_items.append("Address proof")

        if not missing_items:
            return {'status': 'Valid', 'message': 'All required documents seem to be present.'}
        else:
            return {'status': 'Invalid', 'message': f"Missing items: {', '.join(missing_items)} - as per RBI KYC clause 3.1(b)."}
            
    except Exception as e:
        print(f"Rule check error: {e}")
        return {'status': 'Error', 'message': 'Could not process KYC rules file.'}

# --- AI Feature 2: Dispute Helper ---

def find_similar_dispute(transaction_id, reason):
    """Finds similar past cases from a local CSV file."""
    try:
        df_cases = pd.read_csv(Config.PAST_CASES_PATH)
        # Simple search for a similar reason
        similar = df_cases[df_cases['resolution_notes'].str.contains(reason, case=False, na=False)]
        
        if not similar.empty:
            first_case = similar.iloc[0]
            return f"Similar issue resolved on {first_case['date']} for customer ID {first_case['customer_id']} (Reason: {first_case['resolution_notes']})."
        return "No similar past cases found."
        
    except Exception as e:
        print(f"Error reading past cases CSV: {e}")
        return "Error finding similar cases."