# config.py
import os

# Get the absolute path of the directory where this file is located
basedir = os.path.abspath(os.path.dirname(__file__))

class Config:
    """Set Flask configuration variables."""

    # --- Core App Config ---
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'a-very-secret-key-that-you-should-change'
    
    # --- Database Config ---
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'instance', 'bank.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # --- Project-Specific File Paths ---
    
    # Path to your downloaded AI model
    LLM_MODEL_PATH = os.path.join(basedir, 'models', 'mistral-7b-instruct-v0.2.Q4_K_M.gguf')
    
    # Paths for your local AI data
    KYC_RULES_PATH = os.path.join(basedir, 'static', 'kyc_rules', 'kyc_rules.txt')
    DISPUTE_LOGS_PATH = os.path.join(basedir, 'static', 'dispute_data', 'transaction_logs.csv')
    PAST_CASES_PATH = os.path.join(basedir, 'static', 'dispute_data', 'solved_cases.csv')
    
    # Path for temporary file uploads (e.g., KYC documents)
    UPLOAD_FOLDER = os.path.join(basedir, 'instance', 'uploads')