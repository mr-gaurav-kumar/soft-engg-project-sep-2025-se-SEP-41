# app.py
import os
from flask import Flask, jsonify
from flask_cors import CORS
from config import Config
from models import db
from utils import get_llm  # Import get_llm to load it on startup

def create_app():
    """Flask app factory."""
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # Ensure the instance folder and UPLOAD_FOLDER exist
    try:
        os.makedirs(app.instance_path, exist_ok=True)
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    except OSError as e:
        app.logger.error(f"Error creating instance/upload folders: {e}")

    # Initialize extensions
    db.init_app(app)
    CORS(app, supports_credentials=True) # Enable CORS for frontend

    with app.app_context():
        # Import and register blueprints (routes)
        from auth import auth_bp
        from customer_routes import customer_bp
        from employee_routes import employee_bp
        from ai_routes import ai_bp
        
        app.register_blueprint(auth_bp, url_prefix='/auth')
        app.register_blueprint(customer_bp, url_prefix='/customer')
        app.register_blueprint(employee_bp, url_prefix='/employee')
        app.register_blueprint(ai_bp, url_prefix='/ai')

        # Create database tables if they don't exist
        # You should run the init-db command, but this is a fallback
        db.create_all() 

        # --- Pre-load the LLM model on startup ---
        # This will load the 4.4GB model into GPU memory
        # so the first request isn't slow.
        print("Initializing AI model...")
        get_llm()
        print("AI model ready. Application startup complete.")

    @app.route('/')
    def index():
        return jsonify({'message': 'BankEase Backend is running!'})

    return app

if __name__ == '__main__':
    app = create_app()
    # Note: debug=True is great for development,
    # but the reloader might load the LLM twice.
    # Set debug=False for more stable AI testing.
    app.run(debug=False, host='0.0.0.0', port=5000)