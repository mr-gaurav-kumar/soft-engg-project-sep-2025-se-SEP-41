# customer_routes.py
from flask import Blueprint, jsonify, request, session
from models import db, Customer, Transaction, Spending_category
from utils import login_required, role_required

customer_bp = Blueprint('customer_bp', __name__)

@customer_bp.route('/dashboard', methods=['GET'])
@login_required
@role_required(1) # 1 = Customer
def get_dashboard_data():
    user_id = session['user_id']
    customer = Customer.query.get(user_id)
    
    if not customer:
        return jsonify({'message': 'Customer not found'}), 404

    # Simplified balance calculation
    sent = db.session.query(db.func.sum(Transaction.amount)).filter(Transaction.sender_id == user_id).scalar() or 0
    received = db.session.query(db.func.sum(Transaction.amount)).filter(Transaction.receiver_id == user_id).scalar() or 0
    balance = received - sent

    recent_txns = Transaction.query.filter(
        (Transaction.sender_id == user_id) | (Transaction.receiver_id == user_id)
    ).order_by(Transaction.timestamp.desc()).limit(5).all()
    
    recent_txns_json = [
        {'id': txn.id, 'amount': txn.amount, 'desc': txn.description, 'date': txn.timestamp,
         'type': 'debit' if txn.sender_id == user_id else 'credit'} for txn in recent_txns
    ]

    return jsonify({
        'account_number': customer.account_number,
        'balance': balance,
        'name': customer.name,
        'recent_transactions': recent_txns_json
    }), 200

@customer_bp.route('/transactions', methods=['GET'])
@login_required
@role_required(1)
def get_all_transactions():
    user_id = session['user_id']
    
    query = Transaction.query.filter(
        (Transaction.sender_id == user_id) | (Transaction.receiver_id == user_id)
    ).order_by(Transaction.timestamp.desc())

    all_txns = query.all()
    
    all_txns_json = [
        {'id': txn.id, 'amount': txn.amount, 'desc': txn.description, 'date': txn.timestamp,
         'status': txn.status, 'category': txn.category,
         'type': 'debit' if txn.sender_id == user_id else 'credit'} for txn in all_txns
    ]
    return jsonify(all_txns_json), 200

@customer_bp.route('/profile', methods=['GET', 'PUT'])
@login_required
@role_required(1)
def manage_profile():
    user_id = session['user_id']
    customer = Customer.query.get(user_id)
    
    if request.method == 'GET':
        return jsonify({
            'name': customer.name,
            'email': customer.email,
            'contact_number': customer.contact_number,
            'location': customer.location,
            'pin_code': customer.pin_code
        }), 200
        
    elif request.method == 'PUT':
        data = request.get_json()
        customer.contact_number = data.get('contact_number', customer.contact_number)
        customer.location = data.get('location', customer.location)
        customer.pin_code = data.get('pin_code', customer.pin_code)
        db.session.commit()
        return jsonify({'message': 'Profile updated successfully'}), 200

# customer_routes.py
# ... (all your other routes are above) ...

@customer_bp.route('/create-dummy-data', methods=['POST'])
@login_required
@role_required(1) # 1 = Customer
def create_dummy_data():
    """
    Temporary route to create dummy categories and transactions for testing.
    """
    user_id = session['user_id']
    
    # 1. Create Spending Categories (if they don't exist)
    cat_food = Spending_category.query.filter_by(name='Food').first()
    if not cat_food:
        db.session.add(Spending_category(name='Food', description='Restaurants and groceries'))
        db.session.add(Spending_category(name='Transport', description='Taxis, metro, etc.'))
        db.session.add(Spending_category(name='Salary', description='Income'))
        db.session.commit()

    # 2. Check if transactions already exist to avoid duplicates
    existing = Transaction.query.filter_by(sender_id=user_id, description="Zomato Order").first()
    if existing:
        return jsonify({'message': 'Dummy transactions already exist.'}), 200

    # 3. Create dummy transactions
    txn1 = Transaction(
        sender_id=user_id,
        amount=450.00,
        category="Food",
        description="Zomato Order",
        status="Completed",
        type="DEBIT"
    )
    txn2 = Transaction(
        sender_id=user_id,
        amount=120.00,
        category="Transport",
        description="Uber Ride",
        status="Completed",
        type="DEBIT"
    )
    txn3 = Transaction(
        sender_id=user_id,
        receiver_id=user_id, # Sending to self for this test
        amount=50000.00,
        category="Salary",
        description="Monthly Salary",
        status="Completed",
        type="CREDIT"
    )
    
    db.session.add_all([txn1, txn2, txn3])
    db.session.commit()
    
    return jsonify({
        'message': 'Successfully created categories and 3 dummy transactions.',
        'transaction_ids': [txn1.id, txn2.id, txn3.id]
    }), 201