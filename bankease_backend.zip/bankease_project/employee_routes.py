# employee_routes.py
from flask import Blueprint, jsonify, request, session
from models import db, Customer, Document, Task, Bank_employee
from utils import login_required, role_required

employee_bp = Blueprint('employee_bp', __name__)

@employee_bp.route('/customer-search', methods=['GET'])
@login_required
@role_required(2) # 2 = Employee
def customer_search():
    account_num = request.args.get('account_number')
    customer = Customer.query.filter_by(account_number=account_num).first()
    
    if not customer:
        return jsonify({'message': 'Customer not found'}), 404
        
    return jsonify({
        'id': customer.id,
        'name': customer.name,
        'email': customer.email,
        'account_number': customer.account_number,
        'status': customer.status,
    }), 200

@employee_bp.route('/kyc-queue', methods=['GET'])
@login_required
@role_required(2) # 2 = Employee
def get_pending_kyc():
    pending_docs = Document.query.filter_by(status='Pending Review').all()
    
    pending_list = [
        {
            'doc_id': doc.id,
            'customer_id': doc.customer.id,
            'customer_name': doc.customer.name,
            'upload_date': doc.upload_date,
            'file_path': doc.file_path
        } for doc in pending_docs
    ]
    return jsonify(pending_list), 200

# --- Manager-Only Routes ---

@employee_bp.route('/manager/create-employee', methods=['POST'])
@login_required
@role_required(0) # 0 = Manager
def create_employee():
    data = request.get_json()
    manager_id = session['user_id']
    
    temp_password = "tempPassword123" # Should be randomly generated
    
    new_employee = Bank_employee(
        email=data['email'],
        name=data['name'],
        manager_id=manager_id,
        contact_number=data['contact_number'],
        role=2
    )
    new_employee.set_password(temp_password)
    db.session.add(new_employee)
    db.session.commit()
    
    return jsonify({
        'message': 'Employee created successfully',
        'temp_password': temp_password
    }), 201