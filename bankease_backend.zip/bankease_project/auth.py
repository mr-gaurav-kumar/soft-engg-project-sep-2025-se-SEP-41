# auth.py
from flask import Blueprint, request, jsonify, session
from models import db, Customer, Bank_employee, Bank_manager
from werkzeug.security import generate_password_hash

auth_bp = Blueprint('auth_bp', __name__)

@auth_bp.route('/register/customer', methods=['POST'])
def register_customer():
    data = request.get_json()
    
    if Customer.query.filter_by(email=data['email']).first():
        return jsonify({'message': 'Email already exists'}), 400
    if Customer.query.filter_by(account_number=data['account_number']).first():
        return jsonify({'message': 'Account number already exists'}), 400
        
    new_customer = Customer(
        email=data['email'],
        name=data['name'],
        contact_number=data['contact_number'],
        account_number=data['account_number'],
        location=data['location'],
        pin_code=data['pin_code'],
        role=1 # Customer
    )
    new_customer.set_password(data['password'])
    
    db.session.add(new_customer)
    db.session.commit()
    
    return jsonify({'message': 'Customer registered successfully'}), 201

# Note: Employee/Manager registration is handled by managers, see employee_routes.py

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    role_str = data.get('role') # 'customer', 'employee', 'manager'

    user = None
    if role_str == 'customer':
        user = Customer.query.filter_by(email=email).first()
        role_int = 1
    elif role_str == 'employee':
        user = Bank_employee.query.filter_by(email=email).first()
        role_int = 2
    elif role_str == 'manager':
        user = Bank_manager.query.filter_by(email=email).first()
        role_int = 0
    else:
        return jsonify({'message': 'Invalid role specified'}), 400

    if user and user.check_password(password):
        # Store user info in session
        session['user_id'] = user.id
        session['role'] = role_int # Use the integer role
        return jsonify({
            'message': 'Login successful',
            'user': {'id': user.id, 'name': user.name, 'role': role_str}
        }), 200
    
    return jsonify({'message': 'Invalid credentials or role'}), 401

@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    session.pop('role', None)
    return jsonify({'message': 'Logged out successfully'}), 200

@auth_bp.route('/session_check', methods=['GET'])
def session_check():
    if 'user_id' in session:
        role_int = session.get('role')
        role_str_map = {0: 'manager', 1: 'customer', 2: 'employee'}
        return jsonify({
            'logged_in': True,
            'user': {'id': session['user_id'], 'role': role_str_map.get(role_int)}
        }), 200
    return jsonify({'logged_in': False}), 401

# auth.py
# ... (all your other routes are above) ...

@auth_bp.route('/create-test-accounts', methods=['POST'])
def create_test_accounts():
    """
    Temporary route to create a test manager and employee.
    FOR TESTING ONLY.
    """
    if not Bank_manager.query.filter_by(email='manager@bank.com').first():
        # 1. Create Manager
        manager = Bank_manager(
            email='manager@bank.com',
            name='Manager User',
            contact_number='1111111111',
            role=0
        )
        manager.set_password('password123')
        db.session.add(manager)
        db.session.commit() # Commit manager first to get an ID
        
        # 2. Create Employee
        employee = Bank_employee(
            email='employee@bank.com',
            name='Employee User',
            contact_number='2222222222',
            role=2,
            manager_id=manager.id
        )
        employee.set_password('password123')
        db.session.add(employee)
        db.session.commit()
        
        return jsonify({'message': 'Successfully created manager and employee accounts.'}), 201
        
    return jsonify({'message': 'Test accounts already exist.'}), 200