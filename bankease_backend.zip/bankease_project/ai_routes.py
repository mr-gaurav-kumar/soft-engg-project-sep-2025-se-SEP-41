# ai_routes.py
import os
from flask import Blueprint, jsonify, request, session
from models import db, Customer, Document, Transaction, LLM_interaction, Spending_category
from utils import login_required, role_required, extract_text_from_image, check_kyc_rules, find_similar_dispute, generate_llm_response
from werkzeug.utils import secure_filename
from datetime import datetime
from config import Config

ai_bp = Blueprint('ai_bp', __name__)

# --- AI Feature 1: KYC & Rule Assistant ---
@ai_bp.route('/kyc/verify-document', methods=['POST'])
@login_required
@role_required(2) # 2 = Employee
def verify_kyc_document():
    if 'document' not in request.files:
        return jsonify({'message': 'No document file provided'}), 400
        
    file = request.files['document']
    customer_id = request.form.get('customer_id')
    
    if not customer_id:
        return jsonify({'message': 'No customer ID provided'}), 400

    if file:
        filename = secure_filename(file.filename)
        temp_path = os.path.join(Config.UPLOAD_FOLDER, filename)
        
        try:
            file.save(temp_path)
            
            # 1. Extract text using Tesseract OCR
            extracted_text = extract_text_from_image(temp_path)
            if not extracted_text:
                return jsonify({'message': 'Could not extract text from document'}), 500

            # 2. Compare extracted info with rules (Simple Check)
            rule_check = check_kyc_rules(extracted_text)

            # 3. Use local LLM to summarize
            prompt = f"""
            Q: You are a bank compliance assistant. A bank employee has uploaded a KYC document for a customer.
            The OCR scan of the document produced this text:
            "{extracted_text[:500]}..."
            
            A simple automated rule-check reported this:
            "{rule_check['message']}"

            Based *only* on the extracted text and the rule check, provide a short summary for the bank employee.
            State what is missing or if it looks valid.
            A:
            """
            llm_summary = generate_llm_response(prompt)
            
            # 4. Save document record to DB
            new_doc = Document(
                customer_id=customer_id,
                file_path=temp_path, # In a real app, move this to permanent storage
                status='Pending Review'
            )
            db.session.add(new_doc)
            db.session.commit()
            
            return jsonify({
                'message': 'Document processed for verification',
                'llm_summary': llm_summary,
                'rule_check_status': rule_check['status'],
                'extracted_text_preview': extracted_text[:150]
            }), 200

        except Exception as e:
            return jsonify({'message': f'Error processing file: {str(e)}'}), 500
        finally:
            # Clean up temp file (or move it)
            if os.path.exists(temp_path):
                pass # In a real app, you'd move this, not delete it
                # os.remove(temp_path) 

    return jsonify({'message': 'File upload failed'}), 400

# --- AI Feature 2: Dispute Evidence Pack Generator ---
@ai_bp.route('/dispute/generate-pack', methods=['POST'])
@login_required
@role_required(2) # 2 = Employee
def generate_dispute_pack():
    data = request.get_json()
    transaction_id = data.get('transaction_id')
    
    txn = Transaction.query.get(transaction_id)
    if not txn:
        return jsonify({'message': 'Transaction not found'}), 404
        
    # 1. Get info from DB
    txn_info = f"Transaction ID {txn.id} on {txn.timestamp} for ₹{txn.amount}. Status: {txn.status}, Description: {txn.description}."
    
    # 2. Look into past solved cases (from CSV)
    # We use the 'description' or 'status' as a reason
    similarity_report = find_similar_dispute(txn.id, txn.status)
    
    # 3. Give a draft message for employees via LLM
    prompt = f"""
    Q: You are a dispute resolution assistant. An employee is investigating a complaint for a transaction.
    Transaction Details: {txn_info}
    Analysis of Past Cases: {similarity_report}
    
    Please generate a concise, professional draft message for the employee to send to the customer,
    explaining the likely reason for the transaction's status.
    A:
    """
    llm_draft = generate_llm_response(prompt)
    
    return jsonify({
        'transaction_details': txn_info,
        'similarity_report': similarity_report,
        'draft_explanation': llm_draft
    }), 200

# --- AI Feature 3: Personal Spending Coach ---
@ai_bp.route('/coach/ask', methods=['POST'])
@login_required
@role_required(1) # 1 = Customer
def ask_spending_coach():
    data = request.get_json()
    user_id = session['user_id']
    query = data.get('query')
    
    # 1. Analyze spending from local history (SQLite DB)
    #    THIS IS THE FIRST FIX: We query for *all* transactions, not just 'sender_id'
    transactions = Transaction.query.filter(
        (Transaction.sender_id == user_id) | (Transaction.receiver_id == user_id)
    ).order_by(Transaction.timestamp.desc()).limit(20).all()
    
    # --- THIS IS THE SECOND (MAIN) FIX ---
    # We now build a list that includes both DEBIT and CREDIT
    # and update the prompt to reflect this.
    
    transaction_lines = []
    for t in transactions:
        if t.sender_id == user_id and t.type == 'DEBIT':
            transaction_lines.append(f"- DEBIT: ₹{t.amount} on {t.timestamp.strftime('%Y-%m-%d')} for '{t.description}' (Category: {t.category})")
        elif t.receiver_id == user_id and t.type == 'CREDIT':
            transaction_lines.append(f"+ CREDIT: ₹{t.amount} on {t.timestamp.strftime('%Y-%m-%d')} for '{t.description}' (Category: {t.category})")
    
    spending_data = "\n".join(transaction_lines)
    # --- END OF MAIN FIX ---

    # 2. Chatbot (local LLM) answers in plain language
    #    (Updated prompt to remove "debits only")
    prompt = f"""
    Q: You are a friendly, helpful AI banking assistant. A customer is asking you a question.
    Here is their recent transaction history (debits and credits):
    {spending_data}

    Customer's Question: "{query}"

    Using their transaction history, provide a helpful answer and, if appropriate, a simple financial tip.
    A:
    """
    
    llm_response = generate_llm_response(prompt)
    
    # 3. Save the interaction to the database
    interaction = LLM_interaction(
        user_id=user_id,
        ask_msg=query,
        response_msg=llm_response,
        response_time=datetime.now()
    )
    db.session.add(interaction)
    db.session.commit()
    
    return jsonify({'response': llm_response}), 200